import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})

export class SignUpComponent implements OnInit {
  
  signupForm= new FormGroup({
  name: new FormControl(""),
  userName:new FormControl("",Validators.required),
  password:new FormControl("",[Validators.required,Validators.minLength(8)]),
  email:new FormControl("",Validators.email)
  })
  constructor(public router: Router) { }

  ngOnInit(): void {
  }
  signUpEventHandler(){
    alert("Sign Up completed. Click Ok to move to login page.");
    this.router.navigateByUrl("/login");
  }

}
