import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {Router} from '@angular/router';
import {QuestionSet} from '../question-set';

@Component({
  selector: 'app-question-set',
  templateUrl: './question-set.component.html',
  styleUrls: ['./question-set.component.css']
})
export class QuestionSetComponent implements OnInit {
  currentQuestionNumber:number;
  questionSet:QuestionSet[]=new Array();
  userSelectedAnswer:string[]=new Array();
  currentScore:number;
  // p1:number;
  optA:string="A";
  optB:string="B";
  optC:string="C";
  optD:string="D";
  optStatus:number=-1;
  constructor(public activatedRoute:ActivatedRoute, public router:Router) {
    this.questionSet.push(new QuestionSet ("Question 1: ","For which of the following disciplines is Nobel Prize awarded?", "Physics and Chemistry", "Physiology or Medicine", "Literature, Peace and Economics", "All of the above", "D"));
    this.questionSet.push(new QuestionSet ("Question 2: ", "The Battle of Plassey was fought in ", "1757 ", "1782 ", "1748 ", "1764 ", "A"));
    this.questionSet.push(new QuestionSet ("Question 3: ", "The members of the Rajya Sabha are elected by ", "the people ", "Lok Sabha ", "elected members of the legislative assembly ", "elected members of the legislative council", "C"));
    this.questionSet.push(new QuestionSet ("Question 4: ", "The minimum age to qualify for election to the Lok Sabha is", "25 years", "21 years", "18 years", "35years", "A"));
    this.questionSet.push(new QuestionSet ("Question 5: ", "Which of the following is a non metal that remains liquid at room temperature?", "Phosphorous", "Bromine", "Chlorine", "Helium", "B"));
    this.questionSet.push(new QuestionSet ("Question 6: ", "Which of the following is used in pencils?", "Graphite", "Silicon", "Charcoal", "Phosphorous", "A"));
    this.questionSet.push(new QuestionSet ("Question 7: ", "Washing soda is the common name for", "Sodium carbonate", "Calcium bicarbonate", "Sodium bicarbonate", "Calcium carbonate", "A"));
    this.questionSet.push(new QuestionSet ("Question 8: ", "The hardest substance available on earth is", "Gold", "Iron", "Diamond", "Platinum", "C"));
    this.questionSet.push(new QuestionSet ("Question 9: ", "Which was the 1st non Test playing country to beat India in an international match?", "Canada", "Sri Lanka", "Zimbabwe", "East Africa", "B"));
    this.questionSet.push(new QuestionSet ("Question 10: ", "India won its first Olympic hockey gold in...?", "1928", "1932", "1936", "1948", "A"));
    this.questionSet.push(new QuestionSet ("Question 11: ", "In which year did Milkha Singh win the first National title in the 400 m race?", "1955", "1956", "1957", "1970", "C"));
    this.questionSet.push(new QuestionSet ("Question 12: ", "Which player has scored the most runs in a single Test innings?", "Graham Gooch", "Matthew Hayden", "Brian Lara", "Agarkar", "C"));
    this.questionSet.push(new QuestionSet ("Question 13: ", "Who was the 1st ODI captain for India?", "Ajit Wadekar", "Bishen Singh Bedi", "Nawab Pataudi", "Vinoo Mankad", "A"));
    this.questionSet.push(new QuestionSet ("Question 14: ", "In which decade was the American Institute of Electrical Engineers (AIEE) founded?", "1850s", "1880s", "1930s ", "1950s", "B"));
    this.questionSet.push(new QuestionSet ("Question 15: ", "Changing computer language of 1's and 0's to characters that a person can understand is...", "Highlight", "Clip art", "Decode", "Execute", "C"));
    this.currentScore=0;
  }

  ngOnInit(): void {
    this.currentQuestionNumber=this.activatedRoute.snapshot.params["questionNumber"];
  }

  nextQuestionEventHandler(){
    this.currentQuestionNumber++;
    this.optStatus=-1;
    this.router.navigateByUrl("/question/"+this.currentQuestionNumber);
  }

  optionSelectEventHandler(opt:string,p1:number){
    console.log(opt);
    this.optStatus=p1;
    this.userSelectedAnswer[this.currentQuestionNumber-1]=opt;
  }

  finishTestEventHandler(){
    //let currentScore:number=0;
    for(let i=0;i<this.userSelectedAnswer.length;i++)
    {
      if(this.userSelectedAnswer[i]===this.questionSet[i].correctAnswer)
      this.currentScore++;
    }
    // p1=this.currentScore;
    //console.log(currentScore);
    this.router.navigateByUrl("/testEnd/"+this.currentScore);
  }
}
