import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginEventComponent } from './login-event/login-event.component';
import { StartPageComponent } from './start-page/start-page.component';
import { QuestionSetComponent } from './question-set/question-set.component';
import { TestEndComponent } from './test-end/test-end.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SignUpComponent } from './sign-up/sign-up.component';

const routes: Routes = [
  {path:"login", component:LoginEventComponent},
  {path:"start", component:StartPageComponent},
  {path:"signup", component:SignUpComponent},
  {path:"question/:questionNumber",component:QuestionSetComponent},
  {path:"testEnd/:score", component:TestEndComponent},
  {path:"",redirectTo:"/login", pathMatch:"full"},
  {path:"**", component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
