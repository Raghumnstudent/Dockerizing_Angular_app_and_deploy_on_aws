import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router'
import { Router } from '@angular/router';


@Component({
  selector: 'app-test-end',
  templateUrl: './test-end.component.html',
  styleUrls: ['./test-end.component.css']
})
export class TestEndComponent implements OnInit {
  Score:number;
  constructor(public activatedRoute:ActivatedRoute, public router:Router) {
    this.Score=0;
   }

  ngOnInit(): void {
    this.Score=this.activatedRoute.snapshot.params["score"];
  }

  exitEventHandler(){
    this.router.navigateByUrl("/login");
  }
}

